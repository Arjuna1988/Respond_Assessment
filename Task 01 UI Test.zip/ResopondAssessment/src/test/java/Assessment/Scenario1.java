package Assessment;

	import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

	public class Scenario1 {
	  private WebDriver driver;
	  private String baseUrl;
	  private boolean acceptNextAlert = true;
	  private StringBuffer verificationErrors = new StringBuffer();
	  private JavascriptExecutor js;

	  @BeforeClass(alwaysRun = true)
	  public void setUp() throws Exception {
	    System.setProperty("webdriver.chrome.driver", "/Users/Arjuna/Documents/chromedriver");
	    driver = new ChromeDriver();
	    baseUrl = "https://www.google.com/";
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	    js = (JavascriptExecutor) driver;
	  }

	  @Test
	  public void testSearchTestCase() throws Exception {
	    driver.get("http://automationpractice.com/index.php");
	    driver.manage().window().maximize();
	    driver.findElement(By.id("search_query_top")).clear();
	    driver.findElement(By.id("search_query_top")).sendKeys("blouse");
	    driver.findElement(By.name("submit_search")).click();
	    
	   
	   WebElement label = driver.findElement(By.xpath("//*[@id='center_column']/ul/li/div/div[2]/h5/a"));
	   String expectedResult = "Blouse";
	   Assert.assertEquals(expectedResult, label.getText());
	   //System.out.println("Searched Value is available in the listed product");
	  
	  
	    String title = driver.getTitle();
	    String expectedTitle = "Search - My Store";
	    Assert.assertEquals(title, expectedTitle);
	   // System.out.println("Navigated to Search list page");
	   
	    
	    
	    
	  }

	  @AfterClass(alwaysRun = true)
	  public void tearDown() throws Exception {
	    driver.quit();
	    
	    }
	  

	

	 
	}

