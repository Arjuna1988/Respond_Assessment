package Assessment;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Scenario2 {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  private JavascriptExecutor js;

  @BeforeClass(alwaysRun = true)
  public void setUp() throws Exception {
    System.setProperty("webdriver.chrome.driver", "/Users/Arjuna/Documents/chromedriver");
    driver = new ChromeDriver();
    baseUrl = "https://www.google.com/";
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
    js = (JavascriptExecutor) driver;
  }

  @Test
  public void testFiltersTestCase() throws Exception {
    driver.get("http://automationpractice.com/index.php");
    driver.manage().window().maximize();
    //Click Sector "Women"
    driver.findElement(By.linkText("Women")).click();
    //Click on Category = "Dress"
    driver.findElement(By.id("layered_id_attribute_group_7")).click();
    //Click on color = "Beige" 
    driver.findElement(By.id("layered_category_8")).click();
    String expectedColor = driver.findElement(By.xpath("//*[@id=\"ul_layered_id_attribute_group_3\"]/li[1]/label/a")).getText().split(" ")[0];
    Thread.sleep(3000);
    String actualColor = driver.findElement(By.xpath("//div[@id='enabled_filters']/ul/li[2]")).getText().split(": ")[1];
    
    Assert.assertEquals(expectedColor, actualColor);
    System.out.println("Expected Result =" +expectedColor);
    System.out.println("Actual Result =" +actualColor);
    
    String expectedCategory = driver.findElement(By.xpath("//*[@id=\"ul_layered_category_0\"]/li/label/a")).getText().split(" ")[0];
    Thread.sleep(3000);
    String actualCategory = driver.findElement(By.xpath("//div[@id='enabled_filters']/ul/li")).getText().split(": ")[1];
    
    Assert.assertEquals(expectedCategory, actualCategory);
    System.out.println("Expected Category = " +expectedCategory);
    System.out.println("Actual Category = " +actualCategory);
    
  }

  @AfterClass(alwaysRun = true)
  public void tearDown() throws Exception {
    driver.quit();
    
   
    
  }

 
}
