package Assessment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import addToCartPage.AddToCartPage;

public class Scenario3 {
	WebDriver driver;
	AddToCartPage page;
	
	
	
	@BeforeTest
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "/Users/Arjuna/Documents/chromedriver");
		driver = new ChromeDriver();
		driver.get("http://automationpractice.com/index.php");
		driver.manage().window().maximize();
		page=new AddToCartPage(driver);
			
			
		}
	@Test
	public void validateAddToCart() throws InterruptedException {
		Assert.assertTrue(page.validateAddToCart(driver));
		System.out.println("Scenario 03 passed");
		
	}
	 @AfterClass(alwaysRun = true)
	  public void tearDown() throws Exception {
	    driver.quit();
	    //driver.wait();
	   
	    
	  }
	    
	}
	
