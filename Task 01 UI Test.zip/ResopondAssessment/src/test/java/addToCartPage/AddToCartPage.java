package addToCartPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import seleniumimplementation.SeleniumImplementation;


public class AddToCartPage {

	@FindBy(xpath="//*[@id=\"homefeatured\"]/li[3]/div/div[1]/div/a[1]/img")
	WebElement itemImage;
	@FindBy(xpath="//*[@id=\"homefeatured\"]/li[3]/div/div[2]/div[2]/a[2]")
	WebElement btnMore;
	@FindBy(xpath="//*[@id=\"add_to_cart\"]/button")
	WebElement btnAddToCart;
	@FindBy(xpath="//*[@id=\"layer_cart\"]/div[1]/div[1]/span")
	WebElement btnClose;
	@FindBy(xpath="//*[@id=\"header\"]/div[3]/div/div/div[3]/div/a") 
	WebElement cartText;
	
	
	SeleniumImplementation selenium;

	public AddToCartPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		selenium = new SeleniumImplementation();
	}
	
	public boolean validateAddToCart(WebDriver driver) throws InterruptedException {
		selenium.performMouseHower(itemImage, driver);
		selenium.click(btnMore);
		
		selenium.click(btnAddToCart);
		Thread.sleep(5000);
		
		selenium.click(btnClose);
		
		selenium.refresh(driver);
		//System.out.println(cartText.getText().split(" ")[1]);
		
		
		return selenium.validateText(cartText.getText().split(" ")[1], "1");
		
	}
	
}
